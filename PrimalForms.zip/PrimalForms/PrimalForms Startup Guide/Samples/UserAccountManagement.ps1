#UserAccountManagement.ps1
#NOTE: This script requires access to an Active Directory Domain 
#and assumes you have domain admin credentials.


Function Get-IsEnabled {
    Param([string]$username=$(Throw "You must specify a user's CN"))
    
#    This function will look at the useraccountcontrol flag and
#   and return $True if the account is enabled
          
   New-Variable ADS_UF_ACCOUNTDISABLE 2 -Option constant
        
   #define our searcher object
    $Searcher = New-Object DirectoryServices.DirectorySearcher
    
    # find the account
    $filter="(&(objectCategory=person)(objectClass=user)(cn=$username))"
    $searcher.filter=$filter
    
    #get the user account
    $result=$searcher.findOne() 
    [ADSI]$user=$result.path
    $flag=$user.userAccountcontrol.value 
    
    if ($flag) {
        if ($flag -band $ADS_UF_ACCOUNTDISABLE) {
#           Write-Host "account is disabled "
          write $False
         }
         else {
#           Write-Host "account is enabled"
          write $True
         }
    }
 else {
    Write-Warning "Failed to find $username"
 }

}

Function EnableDisable-UserAccount {
    Param([string]$username=$(Throw "You must specify a user's CN"))
    
#    This function will look at the useraccountcontrol flag and
#    determine if the account is enabled or disabled. It will 
#    flip the bits to enable a disabled account or disable an enabled 
#    account.
          
   New-Variable ADS_UF_ACCOUNTDISABLE 2 -Option constant
        
   #define our searcher object
    $Searcher = New-Object DirectoryServices.DirectorySearcher
    
    # find the account
    $filter="(&(objectCategory=person)(objectClass=user)(cn=$username))"
    $searcher.filter=$filter
    
    #get the user account
    $result=$searcher.findOne() 
    [ADSI]$user=$result.path
    $flag=$user.userAccountcontrol.value 
    
    if ($flag) {
        if ($flag -band $ADS_UF_ACCOUNTDISABLE) {
#           Write-Host "account is disabled and enabling"
          $user.useraccountcontrol=$flag -bxor $ADS_UF_ACCOUNTDISABLE
         }
         else {
#           Write-Host "account is enabled and disabling"
          $user.useraccountcontrol=$flag -bor $ADS_UF_ACCOUNTDISABLE
         }
          $user.SetInfo()
    }
 else {
    Write-Warning "Failed to find $username"
 }

}


Function Change-Userpassword {
    Param([string]$username=$(Throw "You must specify a user's CN"),
          [string]$password="P@ssw0rd",
          [switch]$forceChange
          )
          
   #define our searcher object
    $Searcher = New-Object DirectoryServices.DirectorySearcher
    
    # find the account
    $filter="(&(objectCategory=person)(objectClass=user)(cn=$username))"
    $searcher.filter=$filter
    
    #get the user account
    $result=$searcher.findOne() 
    [ADSI]$user=$result.path
    
    #change the password
    $user.SetPassword($password)
    
    #if -forcechange then modify user account to force user to change 
    #password at next logon
    if ($forceChange) 
    {
        $user.Put("pwdLastSet",0) 
        $user.SetInfo()
     } 

}

Function Get-UserAccount {
    Param ([string]$username="Administrator")  
    #define some functions used in the script
    #get the age of the password in days
    #a value of 0 means just set or needs to be set
    #the value of $LastSet will be a large integer
    #indicating the number seconds since 1/1/1601
    #since the password was set
    
    Function Get-UTCAge {
        #get date time of the last password change
            Param([int64]$Last=0)
            if ($Last -eq 0) {
                write 0
            } else {
                #clock starts counting from 1/1/1601.
                [datetime]$utc="1/1/1601"
                #calculate the number of days based on the int64 number
                $i=$Last/864000000000
                
                #Add the number of days to 1/1/1601
                #and write the result to the pipeline
                write ($utc.AddDays($i))
            }
        } # end Get-UTCAge function
    
    Function Get-PwdAge {
    
      Param([int64]$LastSet=0) 
      
      
        if ($LastSet -eq 0) {
            write "0"
        } else {
            #get the date the password was last changed
            [datetime]$ChangeDate=Get-UTCAge $LastSet
            
            #get the current date and time
            [datetime]$RightNow=Get-Date
            
            #write the difference in days
            write $RightNow.Subtract($ChangeDate).Days
        }
    } #end Get-PwdAge function
        
         
    #main code
    #define some constants
    
    New-Variable ADS_UF_ACCOUNTDISABLE 0x0002 -Option Constant
    New-Variable ADS_UF_PASSWD_CANT_CHANGE 0x0040 -Option Constant
    New-Variable ADS_UF_DONT_EXPIRE_PASSWD 0x10000 -Option Constant
    New-Variable ADS_UF_PASSWD_EXPIRED 0x800000 -Option Constant
    
    #define our searcher object
    $Searcher = New-Object DirectoryServices.DirectorySearcher
    
    # find the account
    $filter="(&(objectCategory=person)(objectClass=user)(cn=$username))"
    $searcher.filter=$filter
    
    #get the user account
    $searcher.findOne() | ForEach-Object {
    
    #get password properties from useraccountcontrol field
        if ($_.properties.item("useraccountcontrol")[0] -band $ADS_UF_DONT_EXPIRE_PASSWD) {
            $pwdNeverExpires=$True
         }
         else {
            $pwdNeverExpires=$False
         }
         
         #Password expired should be calculated from a computed UAC value
         $user=$_.GetDirectoryEntry()
         $user.psbase.refreshcache("msDS-User-Account-Control-Computed")
         [int]$computed=$user.psbase.properties.item("msDS-User-Account-Control-Computed").value
            
         if ($computed -band $ADS_UF_PASSWD_EXPIRED) {
            $pwdExpired=$True
         }
         else {
            $pwdExpired=$False
         }
         
         #check if user can change their password
         if ($_.properties.item("useraccountcontrol")[0] -band $ADS_UF_PASSWD_CANT_CHANGE) {
            $pwdChangeAllowed=$False
         }
         else {
            $pwdChangeAllowed=$True
         }
        #create a custom object for the account and password properties
        $obj=New-Object PSObject
        
        #add properties to the object
        $obj | Add-Member -MemberType NoteProperty -Name "Name" -Value $_.properties.item("name")[0]
        $obj | Add-Member -MemberType NoteProperty -Name "DN" -Value $_.properties.item("distinguishedname")[0]
        $obj | Add-Member -MemberType NoteProperty -Name "Description" -Value $_.properties.item("description")[0]
        $obj | Add-Member -MemberType NoteProperty -Name "AccountCreated" -Value $_.properties.item("whencreated")[0]
        $obj | Add-Member -MemberType NoteProperty -Name "AccountModified" -Value $_.properties.item("WhenChanged")[0]
        $obj | Add-Member -MemberType NoteProperty -Name "LastLogon" -Value (Get-UTCAge $_.properties.item("lastlogon")[0])
        $obj | Add-Member -MemberType NoteProperty -Name "PasswordLastChanged" -Value (Get-UTCAge $_.properties.item("pwdlastset")[0])
        $obj | Add-Member -MemberType NoteProperty -Name "PasswordAge" -Value (Get-PwdAge $_.properties.item("pwdlastset")[0])
        $obj | Add-Member -MemberType NoteProperty -Name "PasswordExpired" -Value $pwdExpired
        $obj | Add-Member -MemberType NoteProperty -Name "PasswordNeverExpires" -Value $pwdNeverExpires
        $obj | Add-Member -MemberType NoteProperty -Name "PasswordChangeAllowed" -Value $pwdChangeAllowed
        
        #write object to the pipeline
        write $obj
        
     } #end foreach
}

#main part of script

##################################################################
# Code Generated by: SAPIEN Technologies PrimalForms 2009
# Generated On: '10/23/2008'
##################################################################

#region Import the Assembles
[reflection.assembly]::loadwithpartialname("System.Drawing") | Out-Null
[reflection.assembly]::loadwithpartialname("System.Windows.Forms") | Out-Null
#endregion

#region Generated Form Objects
$form1 = New-Object System.Windows.Forms.Form
$label2 = New-Object System.Windows.Forms.Label
$radioDisabled = New-Object System.Windows.Forms.RadioButton
$radioEnabled = New-Object System.Windows.Forms.RadioButton
$rtbAccountInfo = New-Object System.Windows.Forms.RichTextBox
$btnQuit = New-Object System.Windows.Forms.Button
$listUsers = New-Object System.Windows.Forms.ListBox
$chkForceChange = New-Object System.Windows.Forms.CheckBox
$lblNewPassword = New-Object System.Windows.Forms.Label
$txtPassword = New-Object System.Windows.Forms.TextBox
$btnReset = New-Object System.Windows.Forms.Button
$progressBar1 = New-Object System.Windows.Forms.ProgressBar
$statusBar1 = New-Object System.Windows.Forms.StatusBar
$label1 = New-Object System.Windows.Forms.Label
#endregion Generated Form Objects

#----------------------------------------------
#Generated Event Script Blocks
#----------------------------------------------
#Provide Custom Code for events specified in PrimalForms.

$btnReset_OnClick= 
{
   $password=($txtPassword.Text).Trim()
    
    if ($password.length -eq 0) {
    Write-Warning "Blank passwords are not allowed"
    Return
    }
    
    $user=$listUsers.Selecteditem
    $statusBar1.Text="Resetting password for {0}" -f $listUsers.SelectedItem
    
    if ($chkForceChange.Checked) {
      Change-Userpassword -username $user -password $password -forcechange
    }
    else {
      Change-Userpassword -username $user -password $password
    }
   #refresh the user account 
   
   &$GetUser

   #reset defaults
   $txtPassword.text=""
   $chkForceChange.Checked=$True
}

$Populate= 
{
    $statusBar1.text="Getting users"
    
    $searcher=New-Object DirectoryServices.DirectorySearcher
    $searcher.Filter="(&(objectcategory=person)(objectclass=user))"
    $searcher.pageSize=100
    $progressBar1.value=2
    $users=$searcher.FindAll()
      
    $i=0
    if ($users) {
    $users | foreach {
      $listUsers.Items.add($_.Properties.cn[0])
      $i++
      $progressBar1.value=($i/$users.count) * 100
    }
        
    $statusBar1.text="Ready"
    $progressBar1.Visible=$False
    $label1.Visible=$True
    $listUsers.Visible=$True
    $lblNewPassword.Visible=$True
    $chkForceChange.Visible=$True
    $txtPassword.Visible=$True
    $btnReset.Visible=$True
    $btnQuit.Visible=$True
    $rtbAccountInfo.Visible=$True
    $radioEnabled.Visible=$True
    $radioDisabled.Visible=$True
    #select the first user in the list
    $listUsers.SelectedIndex=0
    
    }
    else {
    #close the form if there are errors getting users
    $form1.close()
    }
}

$btnQuit_OnClick= 
{
    $form1.close()
}

$GetUser= 
{
    $statusBar1.text="Getting account information for {0}" -f $listUsers.SelectedItem
    $user=Get-UserAccount $listUsers.SelectedItem | Out-String
    $rtbAccountInfo.Text=$user.Trim() 
    
    #get enable/disable information
    if (Get-IsEnabled $listUsers.SelectedItem) {
      $radioEnabled.checked=$True
    }
    else {
      $radioDisabled.Checked=$True
    }
    
    $statusBar1.Text="Ready"
}

$ChangeAccount= 
{
    #flip enable/disable status
    if ($radioEnabled.Checked) {
        $statusBar1.Text="Disabling {0}" -f $listUsers.SelectedItem
    }
    else {
         $statusBar1.Text="Enabling {0}" -f $listUsers.SelectedItem
    }
    
    EnableDisable-UserAccount $listUsers.SelectedItem
    
    #refresh user account information
    &$GetUser 
}

$ShowTip= 
{
   $label2.Visible=$True
}

$HideTip= 
{
   $label2.Visible=$False
}

#----------------------------------------------
#region Generated Form Code
$form1.Text = 'User Account Management'
$form1.Name = 'form1'
$form1.DataBindings.DefaultDataSourceUpdateMode = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 575
$System_Drawing_Size.Height = 266
$form1.ClientSize = $System_Drawing_Size
$form1.FormBorderStyle = 3
$form1.add_Shown($Populate)

$label2.TabIndex = 12
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 167
$System_Drawing_Size.Height = 47
$label2.Size = $System_Drawing_Size
$label2.Visible = $False
$label2.Text = 'Enable or disable an account by selecting a button. The change is immediate.'
$label2.ForeColor = [System.Drawing.Color]::FromArgb(255,128,128,255)

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 382
$System_Drawing_Point.Y = 182
$label2.Location = $System_Drawing_Point
$label2.DataBindings.DefaultDataSourceUpdateMode = 0
$label2.Name = 'label2'

$form1.Controls.Add($label2)

$radioDisabled.TabIndex = 11
$radioDisabled.Name = 'radioDisabled'
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 77
$System_Drawing_Size.Height = 24
$radioDisabled.Size = $System_Drawing_Size
$radioDisabled.UseVisualStyleBackColor = $True

$radioDisabled.Visible = $False
$radioDisabled.Text = 'Disabled'

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 299
$System_Drawing_Point.Y = 201
$radioDisabled.Location = $System_Drawing_Point
$radioDisabled.DataBindings.DefaultDataSourceUpdateMode = 0
$radioDisabled.TabStop = $True
$radioDisabled.add_MouseLeave($HideTip)
$radioDisabled.add_MouseEnter($ShowTip)
$radioDisabled.add_Click($ChangeAccount)

$form1.Controls.Add($radioDisabled)

$radioEnabled.TabIndex = 10
$radioEnabled.Name = 'radioEnabled'
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 77
$System_Drawing_Size.Height = 24
$radioEnabled.Size = $System_Drawing_Size
$radioEnabled.UseVisualStyleBackColor = $True

$radioEnabled.Visible = $False
$radioEnabled.Checked=$True
$radioEnabled.Text = 'Enabled'

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 299
$System_Drawing_Point.Y = 178
$radioEnabled.Location = $System_Drawing_Point
$radioEnabled.DataBindings.DefaultDataSourceUpdateMode = 0
$radioEnabled.TabStop = $True
$radioEnabled.add_MouseLeave($HideTip)
$radioEnabled.add_MouseEnter($ShowTip)
$radioEnabled.add_Click($ChangeAccount)

$form1.Controls.Add($radioEnabled)

$rtbAccountInfo.Name = 'rtbAccountInfo'
$rtbAccountInfo.ReadOnly = $True
$rtbAccountInfo.Visible = $False
$rtbAccountInfo.Font = New-Object System.Drawing.Font("Lucida Console",8.25,0,3,1)
$rtbAccountInfo.Text = ''
$rtbAccountInfo.DataBindings.DefaultDataSourceUpdateMode = 0
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 204
$System_Drawing_Point.Y = 29
$rtbAccountInfo.Location = $System_Drawing_Point
$rtbAccountInfo.BackColor = [System.Drawing.Color]::FromArgb(255,236,233,216)
$rtbAccountInfo.BorderStyle = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 359
$System_Drawing_Size.Height = 142
$rtbAccountInfo.Size = $System_Drawing_Size
$rtbAccountInfo.TabIndex = 9

$form1.Controls.Add($rtbAccountInfo)

$btnQuit.TabIndex = 8
$btnQuit.Name = 'btnQuit'
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 75
$System_Drawing_Size.Height = 23
$btnQuit.Size = $System_Drawing_Size
$btnQuit.UseVisualStyleBackColor = $True

$btnQuit.Visible = $False
$btnQuit.Text = 'Quit'

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 104
$System_Drawing_Point.Y = 203
$btnQuit.Location = $System_Drawing_Point
$btnQuit.DataBindings.DefaultDataSourceUpdateMode = 0
$btnQuit.add_Click($btnQuit_OnClick)

$form1.Controls.Add($btnQuit)

$listUsers.FormattingEnabled = $True
$listUsers.Visible = $False
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 166
$System_Drawing_Size.Height = 121
$listUsers.Size = $System_Drawing_Size
$listUsers.DataBindings.DefaultDataSourceUpdateMode = 0
$listUsers.Name = 'listUsers'
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 13
$System_Drawing_Point.Y = 29
$listUsers.Location = $System_Drawing_Point
$listUsers.Sorted = $True
$listUsers.TabIndex = 7
$listUsers.add_SelectedIndexChanged($GetUser)

$form1.Controls.Add($listUsers)

$chkForceChange.TabIndex = 6
$chkForceChange.Name = 'chkForceChange'
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$chkForceChange.Size = $System_Drawing_Size
$chkForceChange.UseVisualStyleBackColor = $True

$chkForceChange.Visible = $False
$chkForceChange.Text = 'Force Change'
$chkForceChange.Checked = $True

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 188
$System_Drawing_Point.Y = 177
$chkForceChange.Location = $System_Drawing_Point
$chkForceChange.DataBindings.DefaultDataSourceUpdateMode = 0
$chkForceChange.CheckState = 1

$form1.Controls.Add($chkForceChange)

$lblNewPassword.TabIndex = 5
$lblNewPassword.TextAlign = 256
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 100
$System_Drawing_Size.Height = 23
$lblNewPassword.Size = $System_Drawing_Size
$lblNewPassword.Visible = $False
$lblNewPassword.Text = 'New Password'

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 13
$System_Drawing_Point.Y = 148
$lblNewPassword.Location = $System_Drawing_Point
$lblNewPassword.DataBindings.DefaultDataSourceUpdateMode = 0
$lblNewPassword.Name = 'lblNewPassword'

$form1.Controls.Add($lblNewPassword)

$txtPassword.PasswordChar = "*"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 156
$System_Drawing_Size.Height = 20
$txtPassword.Size = $System_Drawing_Size
$txtPassword.DataBindings.DefaultDataSourceUpdateMode = 0
$txtPassword.Name = 'txtPassword'
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 13
$System_Drawing_Point.Y = 177
$txtPassword.Location = $System_Drawing_Point
$txtPassword.TabIndex = 4
$txtPassword.Visible = $False

$form1.Controls.Add($txtPassword)

$btnReset.TabIndex = 3
$btnReset.Name = 'btnReset'
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 75
$System_Drawing_Size.Height = 23
$btnReset.Size = $System_Drawing_Size
$btnReset.UseVisualStyleBackColor = $True

$btnReset.Visible = $False
$btnReset.Text = 'Reset Password'

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 13
$System_Drawing_Point.Y = 203
$btnReset.Location = $System_Drawing_Point
$btnReset.DataBindings.DefaultDataSourceUpdateMode = 0
$btnReset.add_Click($btnReset_OnClick)

$form1.Controls.Add($btnReset)

$progressBar1.DataBindings.DefaultDataSourceUpdateMode = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 431
$System_Drawing_Size.Height = 23
$progressBar1.Size = $System_Drawing_Size
$progressBar1.TabIndex = 2
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 104
$System_Drawing_Point.Y = 244
$progressBar1.Location = $System_Drawing_Point
$progressBar1.Style = 1
$progressBar1.Name = 'progressBar1'

$form1.Controls.Add($progressBar1)

$statusBar1.Name = 'statusBar1'
$statusBar1.Text = 'Ready'
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 575
$System_Drawing_Size.Height = 22
$statusBar1.Size = $System_Drawing_Size
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 0
$System_Drawing_Point.Y = 244
$statusBar1.Location = $System_Drawing_Point
$statusBar1.DataBindings.DefaultDataSourceUpdateMode = 0
$statusBar1.TabIndex = 1

$form1.Controls.Add($statusBar1)

$label1.TabIndex = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 100
$System_Drawing_Size.Height = 23
$label1.Size = $System_Drawing_Size
$label1.Visible = $False
$label1.Text = 'Select a user'

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 13
$System_Drawing_Point.Y = 13
$label1.Location = $System_Drawing_Point
$label1.DataBindings.DefaultDataSourceUpdateMode = 0
$label1.Name = 'label1'

$form1.Controls.Add($label1)

#endregion Generated Form Code

#Show the Form
$form1.ShowDialog()| Out-Null


